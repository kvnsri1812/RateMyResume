MAIL_SERVER='smtp.gmail.com'
MAIL_USERNAME='resumerating123@gmail.com'
MAIL_PASSWORD= 'resume@123'
MAIL_PORT=465
MAIL_USE_SSL=True

